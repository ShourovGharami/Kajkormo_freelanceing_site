#include<bits/stdc++.h>
#include<cstring>
using namespace std;
int main()
{

    string p,q;
    cin>>p;
    q=p[0];

    return 0;
}



